#include <GDIPlus.au3>

Func _EnhanceLabel($sRawImagePath)
	$g_iImageCounter += 1 ; Increment the counter
	Local $sTimestamp = @YEAR & @MON & @MDAY & "_" & @HOUR & @MIN & @SEC
	Local $sFileName = "Capture_" & StringFormat("%04d", $g_iImageCounter) & ".png"
    ; 1. Load the original
    Local $hImage = _GDIPlus_ImageLoadFromFile($sRawImagePath)
    Local $iW = _GDIPlus_ImageGetWidth($hImage)
    Local $iH = _GDIPlus_ImageGetHeight($hImage)

    ; 2. Create the target bitmap
    Local $hBitmap = _GDIPlus_BitmapCreateFromScan0($iW, $iH, 0x0026200A)
    Local $hGraphics = _GDIPlus_ImageGetGraphicsContext($hBitmap)

    ; 3. Setup Grayscale Attributes
    Local $hImgAttrib = _GDIPlus_ImageAttributesCreate()
    Local $tGrayMatrix = _GDIPlus_ColorMatrixCreateGrayScale()
    _GDIPlus_ImageAttributesSetColorMatrix($hImgAttrib, 0, True, $tGrayMatrix)

    ; 4. Draw with Grayscale filter
    _GDIPlus_GraphicsDrawImageRectRect($hGraphics, $hImage, 0, 0, $iW, $iH, 0, 0, $iW, $iH, $hImgAttrib, 2)

    ; 5. Cleanup Graphics and Attributes
    _GDIPlus_GraphicsDispose($hGraphics)
    _GDIPlus_ImageAttributesDispose($hImgAttrib)

    ; 6. Save as PNG
	Local $sDir = @ScriptDir & "\GrayScaleImg"

    ; Ensure directory exists
    If Not FileExists($sDir) Then DirCreate($sDir)
	Local $sOutputPath = $sDir & "\" & $sFileName
    Local $sCLSID = _GDIPlus_EncodersGetCLSID("png")
    Local $iResult = _GDIPlus_ImageSaveToFileEx($hBitmap, $sOutputPath, $sCLSID)

    ; Final cleanup
    _GDIPlus_BitmapDispose($hBitmap)
    _GDIPlus_ImageDispose($hImage)

    Return $iResult ? $sOutputPath : ""
EndFunc