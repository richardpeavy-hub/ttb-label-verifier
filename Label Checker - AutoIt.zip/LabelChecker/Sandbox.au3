#include "GetLabels.au3" ; Include your module
; --- Add this to your debug_test.au3 later ---
#include "EnhanceLabel.au3"
#include "ReadTextFromImage.au3"
;#include "ProcessOCR.au3"
#include <GDIPlus.au3>

_GDIPlus_Startup()

; Define a test path (change this to a folder with some images for testing)
Global $sTestFolder = @ScriptDir & "\Labels"

; Execute the module
Global $aResult = _GetLabelFiles($sTestFolder)
Global $g_iImageCounter = 0 ; Initialize this at the start of your program

; Check for errors
If @error Then
    ConsoleWrite("Test Failed: No files found or directory error." & @CRLF)
Else
    ; Successful execution: Output the findings to the Console
    ConsoleWrite("--- Test Passed ---" & @CRLF)
    ConsoleWrite("Files found: " & $aResult[0][0] & @CRLF & @CRLF)

    ; Loop through to display what we found
    For $i = 1 To $aResult[0][0]
        ConsoleWrite("File " & $i & ": " & $aResult[$i][1] & @CRLF)
    Next
EndIf

; Now you can test the whole pipeline
For $i = 1 To $aResult[0][0]
    Local $sClean = _EnhanceLabel($sTestFolder & "\" & $aResult[$i][1])
    ; Local $sText = _PerformOCR($sClean)
    ; ConsoleWrite("Result for " & $aResult[$i][1] & ": " & $sText & @CRLF)
Next

; Ensure the output directory for text exists
Local $sTextOutputDir = @ScriptDir & "\ExtractedText"
If Not FileExists($sTextOutputDir) Then DirCreate($sTextOutputDir)

; Loop through all captured images
For $i = 1 To $g_iImageCounter
    ; Construct the filename based on our counter format (e.g., Capture_0001.png)
    Local $sImageName = "Capture_" & StringFormat("%04d", $i) & ".png"
    Local $sImagePath = @ScriptDir & "\GrayScaleImg\" & $sImageName

    ; Ensure the image exists before trying to read it
    If FileExists($sImagePath) Then
        Local $sText = _ReadTextFromImage($sImagePath)

        ; Save the extracted text to a corresponding .txt file
        Local $sTextFile = $sTextOutputDir & "\Capture_" & StringFormat("%04d", $i) & ".txt"
        Local $hFile = FileOpen($sTextFile, 2) ; 2 = Overwrite mode
        If $hFile <> -1 Then
            FileWrite($hFile, $sText)
            FileClose($hFile)
        EndIf

        ConsoleWrite("Processed: " & $sImageName & @CRLF)
    Else
        ConsoleWrite("! Image not found: " & $sImagePath & @CRLF)
    EndIf
Next

ConsoleWrite("Batch processing complete." & @CRLF)

_GDIPlus_Shutdown()