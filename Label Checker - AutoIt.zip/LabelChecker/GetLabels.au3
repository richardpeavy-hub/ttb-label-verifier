; --- Module: File Discovery ---
; Returns a 2D Array [Count][2] -> [Index, Filename]
Func _GetLabelFiles($sSourceDir)
    Local $sSearch = FileFindFirstFile($sSourceDir & "\*.png") ; Or *.jpg
    If $sSearch = -1 Then Return SetError(1, 0, "")

    Local $aFiles[1][2] = [[0, ""]]
    Local $iCount = 0

    While 1
        Local $sFile = FileFindNextFile($sSearch)
        If @error Then ExitLoop

        $iCount += 1
        ReDim $aFiles[$iCount + 1][2]
        $aFiles[$iCount][0] = $iCount
        $aFiles[$iCount][1] = $sFile
    WEnd

    FileClose($sSearch)
    $aFiles[0][0] = $iCount ; Store the total count in index 0
    Return $aFiles
EndFunc