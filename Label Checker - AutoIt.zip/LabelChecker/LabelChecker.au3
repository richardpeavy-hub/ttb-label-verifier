; --- The AutoIt OCR Core ---
#include <MsgBoxConstants.au3>
#include <GDIPlus.au3>

; Load settings
Global $sTessPath = IniRead(@ScriptDir & "\config.ini", "Paths", "TesseractPath", "C:\Program Files\Tesseract-OCR\tesseract.exe")
Global $sWorkDir = IniRead(@ScriptDir & "\config.ini", "Paths", "WorkDir", @TempDir & "\OCR_Work")
Global $iThreshold = IniRead(@ScriptDir & "\config.ini", "ScanSettings", "Threshold", 128)

; Create work directory if it doesn't exist
If Not FileExists($sWorkDir) Then DirCreate($sWorkDir)

_GDIPlus_Startup()

$sTessPath = IniRead("config.ini", "Paths", "Tesseract", "C:\Program Files\Tesseract-OCR\tesseract.exe")

Func _PerformOCR($sImagePath)
    ; Use the global variable we set up earlier
    Local $sOutputBase = $sWorkDir & "\ocr_result"

    ; Run Tesseract
    ; Note: The .txt extension is automatically added by Tesseract
    RunWait('"' & $sTessPath & '" "' & $sImagePath & '" "' & $sOutputBase & '" -l eng --psm 7', "", @SW_HIDE)

    ; Read the result file
    Local $sText = FileRead($sOutputBase & ".txt")
    Return $sText
EndFunc

Func _EnhanceImage($sFilePath)
    Local $hImage = _GDIPlus_ImageLoadFromFile($sFilePath)
    Local $hGraphics = _GDIPlus_ImageGetGraphicsContext($hImage)

    ; Create a Grayscale Matrix
    Local $hMatrix = _GDIPlus_ColorMatrixCreateGrayScale()
    Local $hAttributes = _GDIPlus_ImageAttributesCreate()
    _GDIPlus_ImageAttributesSetColorMatrix($hAttributes, 0, True, $hMatrix)

    ; Save back to a new file (Tesseract prefers clean B&W)
    Local $sEnhancedPath = $sWorkDir & "\enhanced.png"
    _GDIPlus_ImageSaveToFile($hImage, $sEnhancedPath)

    ; Cleanup
    _GDIPlus_ImageAttributesDispose($hAttributes)
    _GDIPlus_GraphicsDispose($hGraphics)
    _GDIPlus_ImageDispose($hImage)

    Return $sEnhancedPath
EndFunc

_GDIPlus_Shutdown()

; 1. Capture a specific region of interest (example coordinates)
_ScreenCapture_Capture($sWorkDir & "\raw.png", 100, 100, 400, 200)

; 2. Enhance it for Tesseract
Local $sCleanFile = _EnhanceImage($sWorkDir & "\raw.png")

; 3. Run OCR
Local $sResult = _PerformOCR($sCleanFile)

ConsoleWrite("OCR Output: " & $sResult & @CRLF)