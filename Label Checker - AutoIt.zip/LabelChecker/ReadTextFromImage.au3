Func _ReadTextFromImage($sImagePath)
    ; 1. Define paths (ensure these point to your actual locations)
    Local $sTesseractPath = "C:\Program Files\Tesseract-OCR\tesseract.exe"
    Local $sOutputBase = StringTrimRight($sImagePath, 4) ; Removes .png for the output name

    ; 2. Run Tesseract (hiding the console window)
    ; The "digits" or "eng" config can be swapped based on your game's font
    RunWait($sTesseractPath & ' "' & $sImagePath & '" "' & $sOutputBase , "", @SW_HIDE)

    ; 3. Read the result
    Local $sText = FileRead($sOutputBase & ".txt")

    ; 4. Clean up the temp text file
    FileDelete($sOutputBase & ".txt")

    Return StringStripWS($sText, 3) ; Removes leading/trailing whitespace
EndFunc